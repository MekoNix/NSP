# Установка
### Для Windows 
1. Установите python версии 3.12 [здесь](https://www.python.org/ftp/python/3.12.1/python-3.12.1-amd64.exe)
2. Распакуйте NSP-main в любую папку
3. Запустите start.bat
4. Ждите установки и запуска серевра
### Для Linux
   1. Установите python3,pip и git

    sudo apt -y install python3 && sudo apt install python-is-python3

    sudo apt -y install python3-pip
      
    sudo apt -y install git
   2. Клонируйте репозиторий с программой

    git clone https://github.com/MekoNix/NSP && cd NSP/

   3. Запустите sh скрипт для запуска

   chmod +x start.sh && ./start.sh

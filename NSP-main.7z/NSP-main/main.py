from Scripts.modules import first_start_check,cls


cls()
first_start_check()
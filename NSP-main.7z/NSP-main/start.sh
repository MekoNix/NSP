#!/bin/sh

python3 main.py
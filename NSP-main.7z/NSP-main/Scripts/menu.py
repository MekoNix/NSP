from colorama import Fore, Back, init
from Scripts.modules import cls
from Server.cli.console import mainserv


def menu_start():  # Вывод меню
    cls()
    mainserv()
